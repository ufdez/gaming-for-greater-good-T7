// Copyright 1998-2020 Epic Games, Inc. All Rights Reserved.

#include "BodyStateDeviceConfig.h"

FBodyStateDeviceConfig::FBodyStateDeviceConfig()
{
	DeviceName = FString(TEXT("Unknown"));
}
