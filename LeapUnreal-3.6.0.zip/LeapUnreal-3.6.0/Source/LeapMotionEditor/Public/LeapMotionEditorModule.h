// Copyright 1998-2020 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Modules/ModuleInterface.h"

class FLeapMotionEditorModule : public IModuleInterface
{
public:
};