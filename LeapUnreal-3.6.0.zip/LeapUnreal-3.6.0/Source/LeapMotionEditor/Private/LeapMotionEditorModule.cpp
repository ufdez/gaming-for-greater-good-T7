// Copyright 1998-2020 Epic Games, Inc. All Rights Reserved.

#include "LeapMotionEditorModule.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FLeapMotionEditorModule, LeapMotionEditor);